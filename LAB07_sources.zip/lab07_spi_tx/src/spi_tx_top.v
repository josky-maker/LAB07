`timescale 1ns/1ps
// 보드 최상위 · 과제11(FPGA→MCU), 과제12(FPGA→FPGA) 송신 측
// INTERVAL_CYCLES마다(기본 1초) DIP 스위치 값을 SPI로 한 바이트 보냅니다.
// DIP 값은 전송 시작 순간에 저장하므로 전송 도중 스위치를 바꿔도 현재 바이트는 그대로입니다.
// LED에는 마지막으로 보낸 값을 표시합니다.
module spi_tx_top #(
    parameter integer HALF_CYCLES = 50,             // 50 MHz → SCK 500 kHz
    parameter integer INTERVAL_CYCLES = 50_000_000  // 1초
)(
    input wire clk_50mhz, rst_p,
    input wire [7:0] sw,
    output wire spi_sck, spi_mosi, spi_cs_n,
    output reg [7:0] led
);
    (* ASYNC_REG="TRUE" *) reg [7:0] sw_sync0, sw_sync1;
    reg [31:0] tick_count;
    reg start;
    wire busy, done;

    spi_master_tx #(.HALF_CYCLES(HALF_CYCLES)) u_spi(
        clk_50mhz, rst_p, start, sw_sync1, spi_sck, spi_mosi, spi_cs_n, busy, done);

    always @(posedge clk_50mhz) begin
        if (rst_p) begin
            sw_sync0 <= 0; sw_sync1 <= 0; tick_count <= 0; start <= 0; led <= 0;
        end else begin
            sw_sync0 <= sw; sw_sync1 <= sw_sync0;
            start <= 0;
            if (tick_count == INTERVAL_CYCLES - 1) begin
                tick_count <= 0;
                start <= 1;
                led <= sw_sync1;
            end else tick_count <= tick_count + 1;
        end
    end
endmodule
