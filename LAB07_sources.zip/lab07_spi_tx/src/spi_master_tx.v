`timescale 1ns/1ps
// SPI 마스터 송신 · Mode 0, 8비트, MSB 먼저 (STM32_3 과제11·12)
// - SCK 대기 상태는 LOW, 주파수 = CLK_HZ / (2 * HALF_CYCLES). 기본 50 MHz / 100 = 500 kHz
// - start가 들어오면 CS_n↓와 함께 MSB를 MOSI에 올려 두고(첫 상승 에지 전 준비),
//   반주기마다 SCK를 뒤집습니다. 하강 에지에서 다음 비트로 바꾸고, 8번째 하강 에지 뒤
//   반주기를 더 기다렸다가 CS_n↑ 합니다.
module spi_master_tx #(parameter integer HALF_CYCLES = 50)(
    input wire clk_50mhz, rst_p,
    input wire start,
    input wire [7:0] tx_byte,
    output reg sck, mosi, cs_n,
    output wire busy,
    output reg done
);
    localparam IDLE = 2'd0, LEAD = 2'd1, SHIFT = 2'd2, TRAIL = 2'd3;
    reg [1:0] state;
    reg [31:0] count;
    reg [7:0] latched;
    reg [2:0] bit_index;
    wire half_done = (count == HALF_CYCLES - 1);
    assign busy = (state != IDLE);

    always @(posedge clk_50mhz) begin
        if (rst_p) begin
            state <= IDLE; count <= 0; sck <= 0; mosi <= 0; cs_n <= 1;
            latched <= 0; bit_index <= 0; done <= 0;
        end else begin
            done <= 0;
            count <= half_done ? 0 : count + 1;
            case (state)
                IDLE: begin
                    count <= 0;
                    if (start) begin
                        latched <= tx_byte;
                        mosi <= tx_byte[7];
                        bit_index <= 3'd7;
                        cs_n <= 0;
                        state <= LEAD;
                    end
                end
                LEAD:                       // CS↓ 뒤 반주기 대기 후 첫 상승 에지
                    if (half_done) begin sck <= 1; state <= SHIFT; end
                SHIFT:
                    if (half_done) begin
                        if (sck) begin      // 하강 에지
                            sck <= 0;
                            if (bit_index == 0) state <= TRAIL;
                            else begin
                                bit_index <= bit_index - 1'b1;
                                mosi <= latched[bit_index - 1'b1];
                            end
                        end else sck <= 1;  // 상승 에지 (수신 측이 읽는 순간)
                    end
                TRAIL:                      // 마지막 하강 에지 뒤 반주기 유지 후 CS↑
                    if (half_done) begin cs_n <= 1; mosi <= 0; done <= 1; state <= IDLE; end
            endcase
        end
    end
endmodule
