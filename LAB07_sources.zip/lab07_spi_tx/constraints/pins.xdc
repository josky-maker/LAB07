# Combo II-DLD (xc7s75fgga484-1) / MAIN CLOCK 50 MHz / 보드 최상위: spi_tx_top
# 출처: lab00/Xilinx S7 Pin Map.xlsx (DLD-Spartan7-Peripheral)
# 과제11: FPGA(마스터) → MCU(슬레이브)   BDIO00(SCK)→PB3, BDIO01(MOSI)→PA7, BDIO02(CS)→PA4, GND↔GND
# 과제12: 이 FPGA의 BDIO00~02 → 수신 FPGA의 BDIO00~02 (같은 번호끼리), GND↔GND
# PORT A ENABLE 스위치 ON. rst_p = KEY01(1번, SW4는 PUSH SWITCH)
# 보낼 값: DIP_SW1~8 → sw[7:0] (SW1이 최상위 비트), 1초마다 1바이트, SCK 500 kHz
set_property PACKAGE_PIN B6 [get_ports clk_50mhz]
set_property PACKAGE_PIN K4 [get_ports rst_p]

set_property PACKAGE_PIN Y1 [get_ports {sw[7]}]
set_property PACKAGE_PIN W3 [get_ports {sw[6]}]
set_property PACKAGE_PIN U2 [get_ports {sw[5]}]
set_property PACKAGE_PIN T1 [get_ports {sw[4]}]
set_property PACKAGE_PIN W4 [get_ports {sw[3]}]
set_property PACKAGE_PIN W1 [get_ports {sw[2]}]
set_property PACKAGE_PIN V4 [get_ports {sw[1]}]
set_property PACKAGE_PIN U4 [get_ports {sw[0]}]

set_property PACKAGE_PIN F8 [get_ports spi_sck]
set_property PACKAGE_PIN E8 [get_ports spi_mosi]
set_property PACKAGE_PIN A7 [get_ports spi_cs_n]

# 마지막으로 보낸 값: LED_D1~D8
set_property PACKAGE_PIN L4 [get_ports {led[7]}]
set_property PACKAGE_PIN M4 [get_ports {led[6]}]
set_property PACKAGE_PIN M2 [get_ports {led[5]}]
set_property PACKAGE_PIN N7 [get_ports {led[4]}]
set_property PACKAGE_PIN M7 [get_ports {led[3]}]
set_property PACKAGE_PIN M3 [get_ports {led[2]}]
set_property PACKAGE_PIN M1 [get_ports {led[1]}]
set_property PACKAGE_PIN N5 [get_ports {led[0]}]

set_property IOSTANDARD LVCMOS33 [get_ports *]
create_clock -name clk_50mhz -period 20.000 [get_ports clk_50mhz]
set_false_path -from [get_ports {rst_p sw[*]}]
