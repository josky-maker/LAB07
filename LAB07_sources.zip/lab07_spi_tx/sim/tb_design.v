`timescale 1ns/1ps
// 과제11 사전 검증 · FPGA 마스터가 주기마다 DIP 값을 Mode 0으로 보내는지 검사합니다.
// 시뮬레이션 축소: HALF_CYCLES=5 → SCK 주기 10클록(100 ns), INTERVAL_CYCLES=400 → 4 µs마다 1바이트.
// 보드 값: HALF_CYCLES=50 → 500 kHz(주기 2 µs), INTERVAL_CYCLES=50,000,000 → 1초마다 1바이트.
module tb;
    // 파형 기록: build/sim/wave.vcd
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, tb);
    end
    localparam integer HALF = 5;
    localparam integer CLK_NS = 10;
    reg clk = 0, rst = 1;
    reg [7:0] sw = 8'h55;
    always #5 clk = ~clk;
    wire sck, mosi, cs_n;
    wire [7:0] led;
    spi_tx_top #(.HALF_CYCLES(HALF), .INTERVAL_CYCLES(400)) dut(clk, rst, sw, sck, mosi, cs_n, led);

    // 수신 측(슬레이브) 모델: CS_n LOW 동안 SCK 상승 에지에서 MOSI를 읽습니다.
    reg [7:0] rx;
    integer bits = 0, bytes = 0;
    time last_mosi_change = 0, last_rise = 0, cs_fall = 0;
    reg [7:0] got [0:15];
    always @(mosi) last_mosi_change = $time;
    always @(negedge cs_n) begin
        if (sck !== 0) $fatal(1, "SCK must be LOW when CS falls");
        bits = 0; cs_fall = $time;
    end
    always @(posedge sck) begin
        if (cs_n !== 0) $fatal(1, "SCK edge while CS high");
        if (bits == 0 && $time - cs_fall < HALF*CLK_NS) $fatal(1, "MSB setup before first rising edge");
        if ($time - last_mosi_change < HALF*CLK_NS) $fatal(1, "MOSI changed too close to rising edge");
        if (bits > 0 && $time - last_rise != 2*HALF*CLK_NS) $fatal(1, "SCK period %0t", $time - last_rise);
        last_rise = $time;
        rx = {rx[6:0], mosi};
        bits = bits + 1;
    end
    always @(posedge cs_n) if (!rst) begin
        if (sck !== 0) $fatal(1, "SCK must be LOW when CS rises");
        if (bits != 8) $fatal(1, "bit count %0d", bits);
        got[bytes] = rx;
        bytes = bytes + 1;
    end

    task expect_byte(input [7:0] value);
        integer n0;
        begin
            n0 = bytes;
            wait (bytes == n0 + 1);
            if (got[n0] !== value) $fatal(1, "sent %h expected %h", got[n0], value);
            if (led !== value) $fatal(1, "LED %h expected %h", led, value);
            $display("  SPI byte %0d = %h", n0, got[n0]);
        end
    endtask

    initial begin
        #50;
        if (cs_n !== 1 || sck !== 0 || led !== 0) $fatal(1, "reset state");
        rst = 0;
        expect_byte(8'h55);              // 0 1 0 1 0 1 0 1
        sw = 8'hA5; expect_byte(8'hA5);  // 1 0 1 0 0 1 0 1
        sw = 8'h00; expect_byte(8'h00);
        sw = 8'hFF; expect_byte(8'hFF);
        // 전송 중 DIP를 바꿔도 현재 바이트는 시작 순간 값 유지, 다음 바이트부터 반영
        sw = 8'h3C;
        wait (cs_n == 0); #(3*HALF*CLK_NS); sw = 8'hC3;
        begin : during
            integer n0; n0 = bytes;
            wait (bytes == n0 + 1);
            if (got[n0] !== 8'h3C) $fatal(1, "byte changed during transfer: %h", got[n0]);
        end
        expect_byte(8'hC3);
        // 주기 확인: 다음 두 바이트의 CS 하강 간격 = INTERVAL 400클록
        begin : interval
            time t0;
            @(negedge cs_n); t0 = $time;
            @(negedge cs_n);
            if ($time - t0 != 400*CLK_NS) $fatal(1, "interval %0t", $time - t0);
        end
        rst = 1; #50;
        if (cs_n !== 1 || sck !== 0 || led !== 0) $fatal(1, "reset after data");
        $display("PASS SPI TX: Mode 0 timing, MSB first, 55/A5/00/FF/3C/C3, value latched, interval, reset");
        $finish;
    end
    initial begin #200000; $fatal(1, "timeout"); end
endmodule
