`timescale 1ns/1ps
// 보드 최상위 · 과제10(MCU→FPGA), 과제12(FPGA→FPGA) 수신 측
// SPI로 받은 바이트를 LED에 표시하고, PC에서 읽기 쉽게 "RX=55\r\n" 형태의
// ASCII 문자열로 보드 USB-UART(F6, 9600 8N1)에 출력합니다. MCU 수신 예제와 같은 형식입니다.
// UART 송신은 LAB3 UART 에코의 uart_tx를 재사용합니다.
module spi_rx_uart #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 9_600
) (
    input wire clk_50mhz, rst_p,
    input wire spi_sck, spi_mosi, spi_cs_n,
    output wire uart_txd,
    output reg [7:0] led
);
    localparam integer DIV = (CLK_HZ + BAUD/2) / BAUD;

    wire [7:0] rx_data;
    wire rx_valid;
    spi_slave_rx u_spi(clk_50mhz, rst_p, spi_sck, spi_mosi, spi_cs_n, rx_data, rx_valid);

    wire tx_ready;
    reg tx_valid;
    reg [7:0] tx_data;
    uart_tx #(.DIV(DIV)) u_tx(
        .clk(clk_50mhz), .rst_p(rst_p), .valid(tx_valid), .data(tx_data),
        .ready(tx_ready), .tx(uart_txd)
    );

    function [7:0] hex_ascii(input [3:0] n);
        hex_ascii = (n < 10) ? (8'h30 + n) : (8'h37 + n);   // 0~9, A~F
    endfunction

    reg [7:0] report;       // 출력 중인 수신값
    reg [2:0] index;        // 보낼 문자 위치 0~6
    reg sending;
    reg [7:0] ch;
    always @* begin
        case (index)
            3'd0: ch = "R";
            3'd1: ch = "X";
            3'd2: ch = "=";
            3'd3: ch = hex_ascii(report[7:4]);
            3'd4: ch = hex_ascii(report[3:0]);
            3'd5: ch = 8'h0D;
            default: ch = 8'h0A;
        endcase
    end

    always @(posedge clk_50mhz) begin
        if (rst_p) begin
            led <= 0; report <= 0; index <= 0; sending <= 0; tx_valid <= 0; tx_data <= 0;
        end else begin
            tx_valid <= 0;
            if (rx_valid) led <= rx_data;
            if (!sending) begin
                if (rx_valid) begin report <= rx_data; index <= 0; sending <= 1; end
            end else if (tx_ready && !tx_valid) begin
                // tx_valid를 낸 다음 클록에는 ready가 아직 1이므로 !tx_valid로 중복 송신을 막습니다.
                tx_data <= ch;
                tx_valid <= 1;
                if (index == 3'd6) sending <= 0;
                else index <= index + 1'b1;
            end
        end
    end
endmodule
