`timescale 1ns/1ps
// SPI 슬레이브 수신 · Mode 0, 8비트, MSB 먼저 (STM32_3 과제10·12)
// - SCK·MOSI·CS_n은 외부 비동기 신호이므로 2단 동기화 후 사용합니다.
// - 동기화된 SCK의 LOW→HIGH(상승 에지)에서 MOSI를 시프트 레지스터에 넣습니다.
// - 8번째 상승 에지에서 data에 저장하고 valid를 한 클록 HIGH로 냅니다.
// - CS_n이 HIGH(선택 해제)면 비트 카운터를 0으로 되돌려, 중간에 끊긴 바이트는 버립니다.
module spi_slave_rx(
    input wire clk_50mhz, rst_p,
    input wire sck, mosi, cs_n,
    output reg [7:0] data,
    output reg valid
);
    (* ASYNC_REG="TRUE" *) reg [1:0] sck_sync, mosi_sync, cs_sync;
    reg sck_prev;
    reg [6:0] shift;
    reg [2:0] bit_count;
    wire sck_rise = sck_sync[1] && !sck_prev;
    always @(posedge clk_50mhz) begin
        if (rst_p) begin
            sck_sync <= 2'b00; mosi_sync <= 2'b00; cs_sync <= 2'b11;
            sck_prev <= 0; shift <= 0; bit_count <= 0; data <= 0; valid <= 0;
        end else begin
            sck_sync <= {sck_sync[0], sck};
            mosi_sync <= {mosi_sync[0], mosi};
            cs_sync <= {cs_sync[0], cs_n};
            sck_prev <= sck_sync[1];
            valid <= 0;
            if (cs_sync[1]) bit_count <= 0;
            else if (sck_rise) begin
                if (bit_count == 3'd7) begin
                    data <= {shift, mosi_sync[1]};
                    valid <= 1;
                end
                shift <= {shift[5:0], mosi_sync[1]};
                bit_count <= bit_count + 1'b1;   // 7 다음은 0으로 넘어감
            end
        end
    end
endmodule
