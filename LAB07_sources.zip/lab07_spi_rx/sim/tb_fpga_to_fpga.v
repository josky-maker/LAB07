`timescale 1ns/1ps
// 과제12 사전 검증 · 송신 FPGA(spi_tx_top)와 수신 FPGA(spi_rx_uart)를 직접 연결합니다.
// 두 보드는 클록이 따로이므로 수신 측 클록을 약간 다르게(10.4 ns) 두어 비동기 상황을 흉내 냅니다.
// 실행: iverilog -g2012 -o f2f.vvp src/uart.v src/spi_slave_rx.v src/spi_rx_uart.v
//         ../lab07_spi_tx/src/spi_master_tx.v ../lab07_spi_tx/src/spi_tx_top.v sim/tb_fpga_to_fpga.v
//       vvp f2f.vvp
module tb_fpga_to_fpga;
    reg clk_tx = 0, clk_rx = 0, rst = 1;
    always #5 clk_tx = ~clk_tx;
    always #5.2 clk_rx = ~clk_rx;
    reg [7:0] sw = 8'h55;
    wire sck, mosi, cs_n, uart_txd;
    wire [7:0] led_tx, led_rx;
    spi_tx_top #(.HALF_CYCLES(25), .INTERVAL_CYCLES(3000)) tx_fpga(clk_tx, rst, sw, sck, mosi, cs_n, led_tx);
    spi_rx_uart #(.CLK_HZ(1000), .BAUD(100)) rx_fpga(clk_rx, rst, sck, mosi, cs_n, uart_txd, led_rx);

    integer received = 0;
    always @(posedge clk_rx) if (rx_fpga.rx_valid) received = received + 1;
    task expect_value(input [7:0] v);
        integer n0;
        begin
            n0 = received;
            wait (received == n0 + 1);
            #20;
            if (led_rx !== v || rx_fpga.rx_data !== v) $fatal(1, "FPGA->FPGA expected %h got %h", v, led_rx);
            $display("  TX FPGA %h -> RX FPGA %h", led_tx, led_rx);
        end
    endtask
    initial begin
        #100 rst = 0;
        expect_value(8'h55);
        sw = 8'hA5; expect_value(8'hA5);
        sw = 8'h00; expect_value(8'h00);
        sw = 8'hFF; expect_value(8'hFF);
        $display("PASS FPGA->FPGA: 55/A5/00/FF with separate clocks");
        $finish;
    end
    initial begin #2000000; $fatal(1, "timeout"); end
endmodule
