`timescale 1ns/1ps
// 과제10 사전 검증 · MCU 마스터 역할로 Mode 0 바이트를 보내고
//   ① spi_slave_rx의 수신값(valid·data·LED)과 ② UART로 출력된 "RX=xx\r\n" 문자열을 검사합니다.
// SCK 반주기 640 ns = MCU 실측 기본값 781.25 kHz와 같은 속도입니다.
// UART는 시뮬레이션 시간을 줄이려고 CLK_HZ=1000, BAUD=100 → 한 비트 = 10클록(100 ns)으로 줄였습니다.
module tb;
    // 파형 기록: build/sim/wave.vcd
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, tb);
    end
    localparam integer SCK_HALF_NS = 640;
    localparam integer UART_BIT_NS = 100;

    reg clk = 0, rst = 1;
    reg sck = 0, mosi = 0, cs_n = 1;
    always #5 clk = ~clk;
    wire uart_txd;
    wire [7:0] led;
    spi_rx_uart #(.CLK_HZ(1000), .BAUD(100)) dut(clk, rst, sck, mosi, cs_n, uart_txd, led);

    // MCU 마스터 모델 (Mode 0): CS↓ → MSB 준비 → 상승 에지 8번, 하강 에지마다 다음 비트 → CS↑
    task spi_send(input [7:0] b, input integer bits);
        integer k;
        begin
            cs_n = 0; mosi = b[7]; #(SCK_HALF_NS);
            for (k = 7; k > 7 - bits; k = k - 1) begin
                sck = 1; #(SCK_HALF_NS);
                sck = 0;
                if (k > 0) mosi = b[k-1];
                #(SCK_HALF_NS);
            end
            cs_n = 1; mosi = 0; #(2*SCK_HALF_NS);
        end
    endtask

    // PC 역할: UART 8N1을 비트 중앙에서 읽어 문자열로 모읍니다.
    reg [8*8-1:0] line;
    integer line_len = 0, lines = 0;
    reg [7:0] ch;
    always @(negedge uart_txd) if (!rst) begin : uart_rx_model
        integer k;
        #(UART_BIT_NS/2);
        for (k = 0; k < 8; k = k + 1) begin #(UART_BIT_NS); ch[k] = uart_txd; end
        #(UART_BIT_NS);
        if (uart_txd !== 1) $fatal(1, "UART stop bit");
        line = {line[8*7-1:0], ch};
        line_len = line_len + 1;
        if (ch == 8'h0A) lines = lines + 1;
    end

    function [7:0] hx(input [3:0] n);
        hx = (n < 10) ? (8'h30 + n) : (8'h37 + n);
    endfunction

    // 한 바이트를 보내고 SPI 수신값과 UART 출력 7글자를 모두 확인
    integer valid_count = 0;
    always @(posedge clk) if (dut.rx_valid) valid_count = valid_count + 1;
    task check_byte(input [7:0] b);
        integer v0, l0;
        begin
            v0 = valid_count; l0 = lines;
            spi_send(b, 8);
            if (valid_count !== v0 + 1) $fatal(1, "valid count for %h", b);
            if (dut.rx_data !== b || led !== b) $fatal(1, "SPI data sent=%h got=%h led=%h", b, dut.rx_data, led);
            wait (lines == l0 + 1);
            if (line[8*7-1:0] !== {"RX=", hx(b[7:4]), hx(b[3:0]), 8'h0D, 8'h0A})
                $fatal(1, "UART text for %h", b);
            $display("  sent %h -> RX=%s%s", b, hx(b[7:4]), hx(b[3:0]));
        end
    endtask

    initial begin
        #50;
        if (uart_txd !== 1 || led !== 0) $fatal(1, "reset state");
        rst = 0; #200;
        check_byte(8'h55);   // 0 1 0 1 0 1 0 1
        check_byte(8'hA5);   // 1 0 1 0 0 1 0 1
        check_byte(8'h00);
        check_byte(8'hFF);
        // CS가 중간에 해제되면(4비트만 전송) 그 바이트는 버리고, 다음 바이트는 정상 수신
        begin : abort_case
            integer v0;
            v0 = valid_count;
            spi_send(8'hF0, 4);
            #2000;
            if (valid_count !== v0) $fatal(1, "partial byte must be ignored");
        end
        check_byte(8'h3C);
        // CS가 HIGH인 동안 SCK가 움직여도 수신하지 않음
        begin : deselected
            integer v0, k;
            v0 = valid_count;
            for (k = 0; k < 8; k = k + 1) begin sck = 1; #(SCK_HALF_NS); sck = 0; #(SCK_HALF_NS); end
            #2000;
            if (valid_count !== v0) $fatal(1, "must ignore SCK while CS high");
        end
        rst = 1; #50;
        if (led !== 0 || uart_txd !== 1) $fatal(1, "reset after data");
        $display("PASS SPI RX: 55/A5/00/FF/3C received, UART RX=xx text, CS abort, CS high ignore, reset");
        $finish;
    end
    initial begin #2000000; $fatal(1, "timeout"); end
endmodule
