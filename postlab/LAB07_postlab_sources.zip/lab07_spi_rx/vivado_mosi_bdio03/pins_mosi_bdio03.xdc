# 우회판: BDIO01(E8)에서 MOSI가 항상 1로 읽혀 MOSI만 BDIO03(G8)으로 옮김
# Combo II-DLD (xc7s75fgga484-1) / MAIN CLOCK 50 MHz / 보드 최상위: spi_rx_uart
# 출처: lab00/Xilinx S7 Pin Map.xlsx (DLD-Spartan7-Peripheral)
# 과제10: MCU(마스터) → FPGA(슬레이브)   PB3(SCK)→BDIO00, PA7(MOSI)→BDIO03, PB6(CS)→BDIO02, GND↔GND
# 과제12: 송신 FPGA의 BDIO00~02 → 이 FPGA의 BDIO00~02 (같은 번호끼리), GND↔GND
# PORT A ENABLE 스위치 ON. rst_p = KEY01(1번, SW4는 PUSH SWITCH)
# 수신값은 USB-UART(F6, 9600 8N1)로 "RX=55" 형식으로 출력, LED_D1~D8에도 표시
set_property PACKAGE_PIN B6 [get_ports clk_50mhz]
set_property PACKAGE_PIN K4 [get_ports rst_p]

set_property PACKAGE_PIN F8 [get_ports spi_sck]
set_property PACKAGE_PIN G8 [get_ports spi_mosi]
set_property PACKAGE_PIN A7 [get_ports spi_cs_n]
set_property PACKAGE_PIN F6 [get_ports uart_txd]

set_property PACKAGE_PIN L4 [get_ports {led[7]}]
set_property PACKAGE_PIN M4 [get_ports {led[6]}]
set_property PACKAGE_PIN M2 [get_ports {led[5]}]
set_property PACKAGE_PIN N7 [get_ports {led[4]}]
set_property PACKAGE_PIN M7 [get_ports {led[3]}]
set_property PACKAGE_PIN M3 [get_ports {led[2]}]
set_property PACKAGE_PIN M1 [get_ports {led[1]}]
set_property PACKAGE_PIN N5 [get_ports {led[0]}]

set_property IOSTANDARD LVCMOS33 [get_ports *]
# 점퍼선이 빠져도 SCK는 LOW(대기), CS_n은 HIGH(선택 해제)로 유지
set_property PULLDOWN true [get_ports spi_sck]
set_property PULLUP true [get_ports spi_cs_n]
create_clock -name clk_50mhz -period 20.000 [get_ports clk_50mhz]
set_false_path -from [get_ports {rst_p spi_sck spi_mosi spi_cs_n}]
